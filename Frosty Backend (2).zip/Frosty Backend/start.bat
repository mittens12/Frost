@echo off
title Frosty Backend
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get v18 or newer from https://nodejs.org
  pause
  exit /b 1
)

if not exist node_modules (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo npm install failed.
    pause
    exit /b 1
  )
)

if not exist data mkdir data
if not exist cloudstorage mkdir cloudstorage
if not exist news mkdir news
:run
echo Starting backend...
node index.js
echo.
echo Backend stopped. Restarting in 5 seconds (close this window to quit)...
timeout /t 5 /nobreak >nul
goto run
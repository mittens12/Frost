﻿process.on("uncaughtException", (e) => console.error("[crash prevented]", e));
process.on("unhandledRejection", (e) => console.error("[unhandled rejection]", e));
const express = require("express");
const http = require("http");
const config = require("./config.json");

const app = express();
app.use((req, res, next) => {
    console.log(`[req] ${req.method} ${req.originalUrl}`);
    next();
});
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
    res.on("finish", () => console.log(`${req.method} ${req.originalUrl.split("?")[0]} -> ${res.statusCode}`));
    next();
});

app.use(require("./src/routes/account"));
app.use(require("./src/routes/profile"));
app.use(require("./src/routes/misc"));
app.use(require("./src/routes/matchmaking"));
app.use((req, res, next) => {
    console.log(`[unhandled] ${req.method} ${req.originalUrl} body=${JSON.stringify(req.body || {}).slice(0, 200)}`);
    next();
});

app.use((req, res) =>
    res.status(404).json({
        errorCode: "errors.com.epicgames.common.not_found",
        errorMessage: "Sorry the resource you were trying to find could not be found",
        numericErrorCode: 1004,
        originatingService: "any",
        intent: "prod",
    })
);

const server = http.createServer(app);
require("./src/xmpp")(server);
server.listen(config.port, () => console.log(`[backend] listening on :${config.port}`));
require("./src/matchmaker").start();

if (config.discord.token) require("./src/bot").start();
else console.log("[bot] discord.token empty in config.json, bot disabled");
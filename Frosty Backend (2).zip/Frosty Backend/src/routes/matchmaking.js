﻿const express = require("express");
const crypto = require("crypto");
const db = require("../db");
const game = require("../game");
const mm = require("../matchmaker");
const config = require("../../config.json");

const router = express.Router();
// Log every matchmaking request so a failing step is visible in the console.
router.use((req, res, next) => {
    if (req.originalUrl.includes("matchmaking")) console.log(`[mm] ${req.method} ${req.originalUrl}`);
    next();
});
router.get("/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId", (req, res) => {
    const parts = String(req.query.bucketId || "").split(":");
    mm.state.build = parts[0] || "0";
    mm.state.playlist = parts[3] || "playlist_defaultsolo";
    res.json({
        serviceUrl: `ws://${config.publicHost}:${config.matchmakerPort}`,
        ticketType: "mms-player",
        payload: Buffer.from(JSON.stringify({ accountId: req.params.accountId })).toString("base64"),
        signature: crypto.randomBytes(16).toString("base64"),
    });
});

router.get("/fortnite/api/matchmaking/session/findPlayer/:id", (q, r) => r.json([]));
router.post("/fortnite/api/matchmaking/session/:sessionId/join", (q, r) => r.status(204).end());

router.get("/fortnite/api/matchmaking/session/:sessionId", (req, res) => {
    const s = mm.sessions.get(req.params.sessionId) || { id: req.params.sessionId, ...mm.state };
    const owner = crypto.randomBytes(16).toString("hex").toUpperCase();
    res.json({
        id: s.id, ownerId: owner, ownerName: "[DS]fortnite-local", serverName: "[DS]fortnite-local",
        serverAddress: config.gameServer.ip, serverPort: config.gameServer.port,
        maxPublicPlayers: 100, openPublicPlayers: 80, maxPrivatePlayers: 0, openPrivatePlayers: 0,
        attributes: {
            REGION_s: "EU", GAMEMODE_s: "FORTATHENA", ALLOWBROADCASTING_b: true, SUBREGION_s: "GB",
            DCID_s: "FORTNITE-LOCAL", tenant_s: "Fortnite", MATCHMAKINGPOOL_s: "Any", STORMSHIELDDEFENSE_i: 0,
            HOTFIXVERSION_i: 0, PLAYLISTNAME_s: s.playlist, SESSIONKEY_s: s.id, TENANT_s: "Fortnite", BEACONPORT_i: 15009,
        },
        publicPlayers: [], privatePlayers: [], totalPlayers: 20, allowJoinInProgress: false, shouldAdvertise: false,
        isDedicated: false, usesStats: false, allowInvites: false, usesPresence: false,
        allowJoinViaPresence: true, allowJoinViaPresenceFriendsOnly: false,
        buildUniqueId: s.build || "0", lastUpdated: new Date().toISOString(), started: false,
    });
});

// Dedicated game server reports results here:
// POST /gameserver/report  header: x-api-secret  body: { accountId, won, kills, xp, vbucks }
router.post("/gameserver/report", (req, res) => {
    if (req.headers["x-api-secret"] !== config.apiSecret) return res.status(401).json({ error: "bad secret" });
    const { accountId, won, kills, xp, vbucks } = req.body || {};
    const acc = db.byId(accountId);
    if (!acc) return res.status(404).json({ error: "account not found" });
    acc.stats.matches++;
    if (won) acc.stats.wins++;
    acc.stats.kills += kills || 0;
    if (xp) game.addXp(acc, xp);
    const completed = game.questProgress(acc, { matches: 1, kills: kills || 0, wins: won ? 1 : 0 });
    // ...existing vbucks / rvn lines...
    res.json({ ok: true, completedQuests: completed.map((x) => x.title) });
    });
    module.exports = router;

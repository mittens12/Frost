﻿const express = require("express");
const db = require("../db");
const game = require("../game");
const { err } = require("../util");

const router = express.Router();

const SLOT = {
    Character: "character", Backpack: "backpack", Pickaxe: "pickaxe", Glider: "glider",
    SkyDiveContrail: "skydivecontrail", MusicPack: "musicpack", LoadingScreen: "loadingscreen",
    Dance: "dance", ItemWrap: "itemwraps",
};

const wrap = (acc, profileId, items, attributes) => ({
    _id: acc.id, accountId: acc.id, created: acc.created, updated: new Date().toISOString(),
    rvn: acc.rvn, wipeNumber: 1, profileId, version: "no_version",
    items, stats: { attributes }, commandRevision: acc.rvn,
});

function athena(acc) {
    const items = {};
    for (const t of acc.items)
        items[t] = { templateId: t, attributes: { max_level_bonus: 0, level: 1, item_seen: 1, xp: 0, variants: [], favorite: false }, quantity: 1 };
    const L = acc.loadout, one = (v) => ({ items: [v || ""] });

    items["sandbox_loadout"] = {
        templateId: "CosmeticLocker:cosmeticlocker_athena",
        attributes: {
            locker_slots_data: {
                slots: {
                    Pickaxe: one(L.pickaxe), Dance: { items: L.dance }, Glider: one(L.glider),
                    Character: one(L.character), Backpack: one(L.backpack), ItemWrap: { items: L.itemwraps },
                    LoadingScreen: one(L.loadingscreen), MusicPack: one(L.musicpack), SkyDiveContrail: one(L.skydivecontrail),
                }
            },
            use_count: 0, banner_icon_template: "", banner_color_template: "", locker_name: "", item_seen: false, favorite: false,
        },
        quantity: 1,
    };
    for (const qu of require("../game").quests(acc).list) {
        items[`Quest:frost_${qu.id}`] = {
            templateId: `Quest:frost_${qu.id}`,
            attributes: {
                creation_time: new Date().toISOString(), level: -1, item_seen: true, playlists: [], sent_new_notification: true,
                challenge_bundle_id: "", xp_reward_scalar: 1, challenge_linked_quest_given: "", quest_pool: "", quest_state: qu.done ? "Claimed" : "Active",
                bucket: "", last_state_change_time: new Date().toISOString(), challenge_linked_quest_parent: "", max_level_bonus: 0, xp: 0,
                quest_rarity: "uncommon", favorite: false, [`completion_frost_${qu.id}`]: qu.progress,
            },
            quantity: 1,
        };
    }
    const b = acc.battlepass;
    return wrap(acc, "athena", items, {
        season_match_boost: 0, loadouts: ["sandbox_loadout"], rested_xp_overflow: 0, mfa_reward_claimed: true,
        quest_manager: {}, book_level: b.level, season_num: require("../../config.json").season, season_update: 0,
        book_xp: b.xp, permissions: [], season: { numWins: acc.stats.wins, numHighBracket: 0, numLowBracket: acc.stats.matches },
        vote_data: {}, lifetime_wins: acc.stats.wins, book_purchased: b.purchased, purchased_battle_pass_tier: b.purchased ? b.level : 0,
        rested_xp_exchange: 1, level: b.level, xp_overflow: 0, rested_xp: 0, rested_xp_mult: 0,
        accountLevel: b.level, competitive_identity: {}, inventory_limit_bonus: 0, daily_rewards: {}, xp: b.xp,
        season_friend_match_boost: 0, active_loadout_index: 0,
        favorite_character: L.character, favorite_backpack: L.backpack, favorite_pickaxe: L.pickaxe,
        favorite_glider: L.glider, favorite_skydivecontrail: L.skydivecontrail, favorite_musicpack: L.musicpack,
        favorite_loadingscreen: L.loadingscreen, favorite_dance: L.dance, favorite_itemwraps: L.itemwraps,
    });
}

function commonCore(acc) {
    return wrap(acc, "common_core", {
        "Currency:MtxPurchased": { templateId: "Currency:MtxPurchased", attributes: { platform: "EpicPC" }, quantity: acc.vbucks },
    }, {
        survey_data: {}, personal_offers: {}, intro_game_played: true, import_friends_claimed: {},
        mtx_purchase_history: {}, undo_cooldowns: [], mtx_affiliate_set: "", inventory_limit_bonus: 0,
        current_mtx_platform: "EpicPC", mtx_affiliate: "", forced_intro_played: "Seen", weekly_purchases: {},
        daily_purchases: {}, ban_history: {}, in_app_purchases: {}, permissions: [], undo_timeout: "min",
        monthly_purchases: {}, allowed_to_send_gifts: true, mfa_enabled: false, allowed_to_receive_gifts: true, gift_history: {},
    });
}

function getProfile(acc, id) {
    if (id === "athena") return athena(acc);
    if (id === "common_core") return commonCore(acc);
    return wrap(acc, id, {}, {});
}

function respond(acc, profileId, extra = {}) {
    return {
        profileRevision: acc.rvn, profileId, profileChangesBaseRevision: acc.rvn,
        profileChanges: [{ changeType: "fullProfileUpdate", profile: getProfile(acc, profileId) }],
        profileCommandRevision: acc.rvn, serverTime: new Date().toISOString(), responseVersion: 1, ...extra,
    };
}

router.post("/fortnite/api/game/v2/profile/:accountId/:side/:command", (req, res) => {
    const acc = db.byId(req.params.accountId);
    if (!acc) return err(res, 404, "errors.com.epicgames.account.account_not_found", "Account not found", 18007);
    const profileId = req.query.profileId || "common_core";
    const body = req.body || {};

    switch (req.params.command) {
        case "EquipBattleRoyaleCustomization": {
            const key = SLOT[body.slotName];
            if (!key) return err(res, 400, "errors.com.epicgames.modules.profiles.invalid_payload", "Invalid slotName", 12800);
            const want = body.itemToSlot || "";
            const owned = want ? acc.items.find((i) => i.toLowerCase() === want.toLowerCase()) : "";
            if (want && !owned) return err(res, 400, "errors.com.epicgames.fortnite.id_invalid", "Item not owned", 16027);
            const cur = acc.loadout[key];
            if (Array.isArray(cur)) {
                const idx = body.indexWithinSlot ?? 0;
                if (idx === -1) acc.loadout[key] = cur.map(() => owned);
                else if (idx >= 0 && idx < cur.length) cur[idx] = owned;
            } else acc.loadout[key] = owned;
            acc.rvn++; db.save();
            return res.json(respond(acc, "athena"));
        }

        case "PurchaseCatalogEntry": {
            console.log(`[shop] purchase offerId=${body.offerId} qty=${body.purchaseQuantity} vbucks=${acc.vbucks}`);
            const qty = Math.max(1, parseInt(body.purchaseQuantity, 10) || 1);
            const r = game.purchase(acc, body.offerId, qty);
            if (r.error) return err(res, 400, r.code, r.error, r.num);
            acc.rvn++; db.save();
            return res.json(respond(acc, "common_core", {
                notifications: [{
                    type: "CatalogPurchase", primary: true,
                    lootResult: { items: r.granted.map((t) => ({ itemType: t, itemGuid: t, itemProfile: "athena", attributes: { platform: "epicpc" }, quantity: 1 })) },
                }],
                multiUpdate: [{
                    profileRevision: acc.rvn, profileId: "athena", profileChangesBaseRevision: acc.rvn,
                    profileChanges: [{ changeType: "fullProfileUpdate", profile: getProfile(acc, "athena") }],
                    profileCommandRevision: acc.rvn,
                }],
            }));
        }

        default:
            // QueryProfile, ClientQuestLogin, SetMtxPlatform, MarkItemSeen, etc.
            return res.json(respond(acc, profileId));
    }
});

module.exports = router;
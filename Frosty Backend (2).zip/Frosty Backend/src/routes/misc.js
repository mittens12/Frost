﻿const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const game = require("../game");
const config = require("../../config.json");

const router = express.Router();
router.use((req, res, next) => {
    if (req.originalUrl.includes("keychain")) {
        console.log(`[keychain] ${req.method} ${req.originalUrl} auth=${req.headers.authorization ? "yes" : "no"}`);
    }
    next();
});
router.use((req, res, next) => {
    if (req.originalUrl.includes("keychain")) {
        console.log(`[keychain] ${req.method} ${req.originalUrl} auth=${req.headers.authorization ? "yes" : "no"}`);
    }
    next();
});
const CS = path.join(__dirname, "..", "..", "cloudstorage");
const NEWS = path.join(__dirname, "..", "..", "news");
if (!fs.existsSync(NEWS)) fs.mkdirSync(NEWS, { recursive: true });
router.use("/news", express.static(NEWS));

// Every image dropped in /news becomes a tab in the lobby news screen (no restart needed).
const newsTabs = () => {
    const base = `http://${config.publicHost}${config.port === 80 ? "" : ":" + config.port}/news/`;
    return fs.readdirSync(NEWS).filter((f) => /\.(png|jpe?g)$/i.test(f)).sort().map((f, i) => {
        const url = base + encodeURIComponent(f), title = f.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
        return {
            entryType: "Website", image: url, tileImage: url, videoMute: false, hidden: false, tabTitleOverride: title,
            _type: "CommonUI Simple Message MOTD", title, body: config.lobbyMessage.body, id: `news${i}`, videoLoop: false,
            videoStreamingEnabled: false, sortingPriority: 0, spotlight: false,
        };
    });
};

const status = () => ({
    serviceInstanceId: "fortnite", status: "UP", message: "Fortnite is online", maintenanceUri: null,
    overrideCatalogIds: ["a7f138b2e51945ffbfdacc1af0541053"], allowedActions: [], banned: false,
    launcherInfoDTO: { appName: "Fortnite", catalogItemId: "4fe75bbc5a674f4f9b356b5c90567da5", namespace: "fn" },
});
router.get("/fortnite/api/storefront/v2/catalog", (q, r) => {
    console.log("[shop] catalog requested");
    r.json(game.catalog());
});
router.get("/lightswitch/api/service/Fortnite/status", (q, r) => r.json(status()));
router.get("/lightswitch/api/service/bulk/status", (q, r) => r.json([status()]));
router.get("/waitingroom/api/waitingroom", (q, r) => r.status(204).end());
router.get(["/fortnite/api/v2/versioncheck/:v", "/fortnite/api/v2/versioncheck"], (q, r) => r.json({ type: "NO_UPDATE" }));
router.get("/fortnite/api/game/v2/enabled_features", (q, r) => r.json([]));
router.post("/fortnite/api/game/v2/grant_access/:id", (q, r) => r.status(204).end());
router.all("/fortnite/api/game/v2/tryPlayOnPlatform/account/:id", (q, r) => r.type("text/plain").send("true"));
router.get("/fortnite/api/game/v2/privacy/account/:id", (q, r) => r.json({ acceptInvites: "public" }));
router.post("/fortnite/api/game/v2/privacy/account/:id", (q, r) => r.status(204).end());
router.get("/fortnite/api/receipts/v1/account/:id/receipts", (q, r) => r.json([]));
router.get("/fortnite/api/game/v2/br-inventory/account/:id", (q, r) => r.json({ stash: { globalcash: 0 } }));
router.get("/eulatracking/api/public/agreements/fn/account/:id", (q, r) => r.status(204).end());
router.post("/datarouter/api/v1/public/data", (q, r) => r.status(204).end());
router.get("/socialban/api/public/v1/:id", (q, r) => r.json({ bans: [], warnings: [] }));
router.get("/party/api/v1/Fortnite/user/:id", (q, r) => r.json({ current: [], pending: [], invites: [], pings: [] }));
// Keychain: array of "<guid>:<base64 AES key>[:<comment>]" strings for your exact client build.
let keychain = [];
try {
    keychain = require("../../keychain.json");
    if (!Array.isArray(keychain)) throw new Error("keychain.json must be a JSON array of strings");
} catch (e) {
    console.error(`[keychain] could not load keychain.json: ${e.message}`);
    keychain = [];
}
if (keychain.length === 0) console.warn("[keychain] keychain.json is empty - client will reject it");
else console.log(`[keychain] loaded ${keychain.length} keys`);

router.get(
    ["/fortnite/api/storefront/v2/keychain", "/fortnite/api/storefront/v2/keychain/*"],
    (q, r) => r.status(200).json(keychain)
);

// Friends (empty lists)
router.get("/friends/api/v1/:id/summary", (q, r) => r.json({
    friends: [], incoming: [], outgoing: [], suggested: [], blocklist: [],
    settings: { acceptInvites: "public" }, limitsReached: { incoming: false, outgoing: false, accepted: false },
}));
router.get("/friends/api/public/friends/:id", (q, r) => r.json([]));
router.get("/friends/api/v1/:id/blocklist", (q, r) => r.json([]));
router.get("/friends/api/v1/:id/recent/fortnite", (q, r) => r.json([]));

// Stats
const stats = (q, r) => r.json({ startTime: 0, endTime: 9223372036854775807, stats: {}, accountId: q.params.id });
router.get("/fortnite/api/statsv2/account/:id", stats);
router.get("/statsproxy/api/statsv2/account/:id", stats);

// Cloud storage (hotfix .ini files)
router.get("/fortnite/api/cloudstorage/system", (q, r) => {
    if (!fs.existsSync(CS)) return r.json([]);
    r.json(fs.readdirSync(CS).filter((f) => f.endsWith(".ini")).map((f) => {
        const p = path.join(CS, f), buf = fs.readFileSync(p);
        return {
            uniqueFilename: f, filename: f,
            hash: crypto.createHash("sha1").update(buf).digest("hex"),
            hash256: crypto.createHash("sha256").update(buf).digest("hex"),
            length: buf.length, contentType: "application/octet-stream",
            uploaded: fs.statSync(p).mtime.toISOString(), storageType: "S3", storageIds: {}, doNotCache: true,
        };
    }));
});
router.get("/fortnite/api/cloudstorage/system/config", (q, r) => r.json({}));
router.get("/fortnite/api/cloudstorage/system/:file", (q, r) => {
    const p = path.join(CS, path.basename(q.params.file));
    if (!fs.existsSync(p)) return r.status(404).json({ errorCode: "errors.com.epicgames.cloudstorage.file_not_found", errorMessage: "File not found", numericErrorCode: 12004 });
    r.type("application/octet-stream").send(fs.readFileSync(p));
});
router.get("/fortnite/api/cloudstorage/user/:id", (q, r) => r.json([]));
router.get("/fortnite/api/cloudstorage/user/:id/:file", (q, r) => r.status(204).end());
router.put("/fortnite/api/cloudstorage/user/:id/:file", (q, r) => r.status(204).end());

// Timeline (season / lobby events)
router.get("/fortnite/api/calendar/v1/timeline", (q, r) => {
    const s = config.season, now = new Date(), end = new Date(now.getTime() + 30 * 864e5).toISOString();
    const sh = game.shop();
    const since = "2018-01-01T00:00:00.000Z";
    r.json({
        channels: {
            "client-matchmaking": { states: [], cacheExpire: end },
            "client-events": {
                states: [{
                    validFrom: since,
                    activeEvents: [
                        { eventType: `EventFlag.Season${s}`, activeUntil: end, activeSince: since },
                        { eventType: `EventFlag.LobbySeason${s}`, activeUntil: end, activeSince: since },
                    ],
                    state: {
                        activeStorefronts: [], eventNamedWeights: {}, seasonNumber: s, seasonTemplateId: `AthenaSeason:athenaseason${s}`,
                        matchXpBonusPoints: 0, seasonBegin: since, seasonEnd: end, seasonDisplayedEnd: end,
                        weeklyStoreEnd: sh.featuredEnd, stwEventStoreEnd: end, stwWeeklyStoreEnd: end, dailyStoreEnd: sh.dailyEnd,
                    },
                }],
                cacheExpire: end,
            },
        },
        eventsTimeOffsetHrs: 0, cacheIntervalMins: 10, currentTime: now.toISOString(),
    });
});

// Content pages (news / lobby background)
router.get("/content/api/pages/fortnite-game", (q, r) => r.json({
    _title: "Fortnite Game", _activeDate: "2018-01-01T00:00:00.000Z", lastModified: new Date().toISOString(),
    _locale: "en-US",
    emergencynotice: {
        news: {
            platform_messages: [], _type: "Battle Royale News",
            messages: [{
                hidden: false, _type: "CommonUI Simple Message Base", subgame: "br", body: config.lobbyMessage.body,
                trackingId: "frost-welcome", spotlight: false, title: config.lobbyMessage.title,
            }],
        }, _title: "emergencynotice", _noIndex: false,
    },
    dynamicbackgrounds: {
        backgrounds: {
            backgrounds: [
                { stage: `season${config.season}`, _type: "DynamicBackground", key: "lobby" },
                { stage: `season${config.season}`, _type: "DynamicBackground", key: "vault" },
            ], _type: "DynamicBackgroundList"
        }, _title: "dynamicbackgrounds", _noIndex: false
    },
}));

module.exports = router;
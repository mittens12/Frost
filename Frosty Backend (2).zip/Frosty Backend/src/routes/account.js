﻿const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db");
const auth = require("../auth");
const { err, uuid } = require("../util");

const router = express.Router();

const pub = (a) => ({
    id: a.id, displayName: a.username, name: "Fortnite", email: a.email,
    failedLoginAttempts: 0, lastLogin: new Date().toISOString(), numberOfDisplayNameChanges: 0,
    ageGroup: "UNKNOWN", headless: false, country: "US", lastName: "Player",
    preferredLanguage: "en", canUpdateDisplayName: false, tfaEnabled: false,
    emailVerified: true, minorVerified: false, minorExpected: false, minorStatus: "UNKNOWN",
});

router.post("/account/api/oauth/token", (req, res) => {
    const b = req.body || {};
    let clientId = "ec684b8c687f479fadea3cb2ad83f5c6";
    const basic = (req.headers.authorization || "").split(" ")[1];
    if (basic) clientId = Buffer.from(basic, "base64").toString().split(":")[0];

    if (b.grant_type === "client_credentials") {
        const t = auth.issue("client", clientId);
        return res.json({
            access_token: t.access, expires_in: 14400, expires_at: new Date(t.expires).toISOString(),
            token_type: "bearer", client_id: clientId, internal_client: true, client_service: "fortnite",
        });
    }

    let acc;
    if (b.grant_type === "password") {
        acc = db.byEmail(b.username);
        if (!acc || !bcrypt.compareSync(String(b.password || ""), acc.passwordHash))
            return err(res, 400, "errors.com.epicgames.account.invalid_account_credentials",
                "Sorry the account credentials you are using are invalid", 18031,
                { error: "invalid_grant", error_description: "Sorry the account credentials you are using are invalid" });
    } else if (b.grant_type === "refresh_token") {
        const r = auth.refreshes.get(b.refresh_token);
        if (!r || r.expires < Date.now()) return err(res, 400, "errors.com.epicgames.account.auth_token.invalid_refresh_token", "Invalid refresh token", 18036);
        acc = db.byId(r.accountId);
    } else if (b.grant_type === "exchange_code") {
        const e = auth.exchanges.get(b.exchange_code);
        if (!e || e.expires < Date.now()) return err(res, 400, "errors.com.epicgames.account.oauth.exchange_code_not_found", "Exchange code not found", 18057);
        auth.exchanges.delete(b.exchange_code);
        acc = db.byId(e.accountId);
    } else {
        return err(res, 400, "errors.com.epicgames.common.oauth.unsupported_grant_type", "Unsupported grant type", 1016);
    }

    if (!acc) return err(res, 404, "errors.com.epicgames.account.account_not_found", "Account not found", 18007);
    if (acc.banned) return err(res, 403, "errors.com.epicgames.account.account_not_active", "Your account is banned.", 18006);

    const t = auth.issue(acc.id, clientId);
    res.json({
        access_token: t.access, expires_in: 28800, expires_at: new Date(t.expires).toISOString(),
        token_type: "bearer", refresh_token: t.refresh, refresh_expires: 115200,
        refresh_expires_at: new Date(t.refreshExpires).toISOString(), account_id: acc.id,
        client_id: clientId, internal_client: true, client_service: "fortnite",
        displayName: acc.username, app: "fortnite", in_app_id: acc.id, device_id: uuid().replace(/-/g, ""),
    });
});

router.get("/account/api/oauth/verify", (req, res) => {
    const s = auth.fromRequest(req);
    if (!s) return err(res, 401, "errors.com.epicgames.common.authentication.token_verification_failed", "Token verification failed", 1014);
    const acc = db.byId(s.accountId);
    res.json({
        token: s.token, session_id: uuid().replace(/-/g, ""), token_type: "bearer", client_id: s.clientId,
        internal_client: true, client_service: "fortnite", account_id: s.accountId,
        expires_in: Math.floor((s.expires - Date.now()) / 1000), expires_at: new Date(s.expires).toISOString(),
        auth_method: "exchange_code", display_name: acc ? acc.username : "", app: "fortnite", in_app_id: s.accountId,
    });
});

router.get("/account/api/oauth/exchange", (req, res) => {
    const s = auth.fromRequest(req);
    if (!s) return err(res, 401, "errors.com.epicgames.common.authorization.authorization_failed", "Unauthorized", 1032);
    res.json({ expiresInSeconds: 300, code: auth.issueExchange(s.accountId, s.clientId), creatingClientId: s.clientId });
});

router.delete("/account/api/oauth/sessions/kill", (req, res) => res.status(204).end());
router.delete("/account/api/oauth/sessions/kill/:token", (req, res) => {
    auth.sessions.delete(req.params.token);
    res.status(204).end();
});

router.get("/account/api/public/account/displayName/:name", (req, res) => {
    const a = db.byUsername(req.params.name);
    if (!a) return err(res, 404, "errors.com.epicgames.account.account_not_found", `Sorry, we couldn't find an account for ${req.params.name}`, 18007);
    res.json(pub(a));
});

router.get("/account/api/public/account/:id/externalAuths", (req, res) => res.json([]));

router.get("/account/api/public/account/:id", (req, res) => {
    const a = db.byId(req.params.id);
    if (!a) return err(res, 404, "errors.com.epicgames.account.account_not_found", "Account not found", 18007);
    res.json(pub(a));
});

router.get("/account/api/public/account", (req, res) => {
    let ids = req.query.accountId || [];
    if (!Array.isArray(ids)) ids = [ids];
    res.json(ids.map(db.byId).filter(Boolean).map((a) => ({ id: a.id, displayName: a.username, externalAuths: {} })));
});

module.exports = router;
﻿const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const bcrypt = require("bcryptjs");
const db = require("./db");
const game = require("./game");
const config = require("../config.json");

const isAdmin = (id) => config.discord.adminIds.includes(id);
const S = (b, n, d) => b.addStringOption((o) => o.setName(n).setDescription(d).setRequired(true));
const N = (b, n, d) => b.addIntegerOption((o) => o.setName(n).setDescription(d).setRequired(true));

const commands = [
    S(S(S(new SlashCommandBuilder().setName("register").setDescription("Create your account"), "email", "Login email"), "username", "In-game name"), "password", "Password (6+ chars)"),
    new SlashCommandBuilder().setName("account").setDescription("View your account"),
    S(new SlashCommandBuilder().setName("changepassword").setDescription("Change your password"), "password", "New password"),
    new SlashCommandBuilder().setName("daily").setDescription("Claim your daily V-Bucks"),
    new SlashCommandBuilder().setName("quests").setDescription("View today's quests"),
    new SlashCommandBuilder().setName("shop").setDescription("Show the current item shop"),
    N(S(new SlashCommandBuilder().setName("addvbucks").setDescription("[Admin] Add V-Bucks"), "username", "Account name"), "amount", "Amount (negative removes)"),
    S(S(new SlashCommandBuilder().setName("giveitem").setDescription("[Admin] Give a cosmetic"), "username", "Account name"), "templateid", "e.g. AthenaCharacter:CID_028_Athena_Commando_F"),
    S(new SlashCommandBuilder().setName("givepass").setDescription("[Admin] Give the Battle Pass"), "username", "Account name"),
    N(S(new SlashCommandBuilder().setName("setlevel").setDescription("[Admin] Set Battle Pass level"), "username", "Account name"), "level", "Level"),
    S(new SlashCommandBuilder().setName("ban").setDescription("[Admin] Ban an account"), "username", "Account name"),
    S(new SlashCommandBuilder().setName("unban").setDescription("[Admin] Unban an account"), "username", "Account name"),
];

const ADMIN_ONLY = ["addvbucks", "giveitem", "givepass", "setlevel", "ban", "unban"];

async function handle(i) {
    const eph = (content) => i.reply({ content, flags: MessageFlags.Ephemeral });
    const name = i.commandName;

    if (ADMIN_ONLY.includes(name) && !isAdmin(i.user.id)) return eph("You are not an admin.");

    if (name === "register") {
        const email = i.options.getString("email").trim();
        const username = i.options.getString("username").trim();
        const password = i.options.getString("password");
        if (db.byDiscord(i.user.id)) return eph("You already have an account.");
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return eph("Invalid email.");
        if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return eph("Username must be 3-16 letters, numbers or underscores.");
        if (password.length < 6) return eph("Password must be at least 6 characters.");
        if (db.byEmail(email) || db.byUsername(username)) return eph("Email or username already taken.");
        db.create({ email, username, passwordHash: bcrypt.hashSync(password, 10), discordId: i.user.id });
        return eph(`Account created. Log in with **${email}** and your password.`);
    }

    if (name === "daily" || name === "quests") {
        const acc = db.byDiscord(i.user.id);
        if (!acc) return eph("You don't have an account. Use /register first.");
        if (name === "daily") {
            const r = game.claimDaily(acc);
            if (!r.ok) {
                const h = Math.floor(r.waitMs / 36e5), m = Math.ceil((r.waitMs % 36e5) / 6e4);
                return eph(`Already claimed. Come back in ${h}h ${m}m.`);
            }
            return eph(`You claimed **${r.amount} V-Bucks**. Balance: ${r.total}.`);
        }
        const list = game.quests(acc).list;
        return eph(list.map((q) => `${q.done ? "✅" : "⬜"} **${q.title}**: ${q.progress}/${q.target} (${q.xp} XP)`).join("\n"));
    }

    if (name === "shop") {
        const s = game.shop();
        const fmt = (l) => l.map((e) => `• **${e.title}**: ${e.price} V-Bucks`).join("\n") || "None";
        return i.reply({
            embeds: [new EmbedBuilder().setTitle("Item Shop").addFields(
                { name: "Daily", value: fmt(s.daily) }, { name: "Featured", value: fmt(s.featured) })]
        });
    }

    if (["account", "changepassword"].includes(name)) {
        const acc = db.byDiscord(i.user.id);
        if (!acc) return eph("You don't have an account. Use /register first.");
        if (name === "changepassword") {
            const pw = i.options.getString("password");
            if (pw.length < 6) return eph("Password must be at least 6 characters.");
            acc.passwordHash = bcrypt.hashSync(pw, 10); db.save();
            return eph("Password changed.");
        }
        return i.reply({
            flags: MessageFlags.Ephemeral, embeds: [new EmbedBuilder().setTitle(acc.username).addFields(
                { name: "V-Bucks", value: String(acc.vbucks), inline: true },
                { name: "Items", value: String(acc.items.length), inline: true },
                { name: "Battle Pass", value: `${acc.battlepass.purchased ? "Owned" : "Not owned"} / Level ${acc.battlepass.level}`, inline: true },
                { name: "Wins / Kills / Matches", value: `${acc.stats.wins} / ${acc.stats.kills} / ${acc.stats.matches}` })]
        });
    }

    // Admin commands
    const target = db.byUsername(i.options.getString("username"));
    if (!target) return eph("Account not found.");

    if (name === "addvbucks") { game.addVbucks(target, i.options.getInteger("amount")); target.rvn++; return eph(`${target.username} now has ${target.vbucks} V-Bucks.`); }
    if (name === "giveitem") { const a = game.grantItems(target, [i.options.getString("templateid")]); target.rvn++; return eph(a.length ? "Item granted." : "They already own it."); }
    if (name === "givepass") { game.givePass(target); target.rvn++; return eph("Battle Pass granted."); }
    if (name === "setlevel") { game.setLevel(target, i.options.getInteger("level")); target.rvn++; return eph(`Level set to ${target.battlepass.level}.`); }
    if (name === "ban") { target.banned = true; db.save(); return eph(`${target.username} banned.`); }
    if (name === "unban") { target.banned = false; db.save(); return eph(`${target.username} unbanned.`); }
}

exports.start = () => {
    const client = new Client({ intents: [GatewayIntentBits.Guilds] });

    client.once("ready", async () => {
        const rest = new REST({ version: "10" }).setToken(config.discord.token);
        const route = config.discord.guildId
            ? Routes.applicationGuildCommands(client.user.id, config.discord.guildId)
            : Routes.applicationCommands(client.user.id);
        try {
            await rest.put(route, { body: commands.map((c) => c.toJSON()) });
            console.log(`[bot] logged in as ${client.user.tag}, commands registered`);
        } catch (e) { console.error("[bot] failed to register commands:", e.message); }
    });

    client.on("interactionCreate", async (i) => {
        if (!i.isChatInputCommand()) return;
        try { await handle(i); }
        catch (e) {
            console.error("[bot]", e);
            if (!i.replied) i.reply({ content: "Something went wrong.", flags: MessageFlags.Ephemeral }).catch(() => { });
        }
    });

    client.login(config.discord.token).catch((e) => console.error("[bot] login failed:", e.message));
};
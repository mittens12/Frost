﻿const { hex } = require("./util");

const sessions = new Map();   // access token -> { accountId, clientId, expires }
const refreshes = new Map();  // refresh token -> { accountId, clientId, expires }
const exchanges = new Map();  // exchange code -> { accountId, clientId, expires }

exports.sessions = sessions;
exports.refreshes = refreshes;
exports.exchanges = exchanges;

exports.issue = (accountId, clientId) => {
    const access = hex(16), refresh = hex(16);
    const expires = Date.now() + 8 * 3600e3;
    const refreshExpires = Date.now() + 32 * 3600e3;
    sessions.set(access, { accountId, clientId, expires });
    refreshes.set(refresh, { accountId, clientId, expires: refreshExpires });
    return { access, refresh, expires, refreshExpires };
};

exports.issueExchange = (accountId, clientId) => {
    const code = hex(16);
    exchanges.set(code, { accountId, clientId, expires: Date.now() + 300e3 });
    return code;
};

exports.fromRequest = (req) => {
    const token = (req.headers.authorization || "").split(" ")[1];
    const s = token && sessions.get(token);
    return s && s.expires > Date.now() ? { token, ...s } : null;
};
﻿const WebSocket = require("ws");
const { uuid } = require("./util");

module.exports = (server) => {
    const wss = new WebSocket.Server({ noServer: true, handleProtocols: () => "xmpp" });
    server.on("upgrade", (req, socket, head) => wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req)));

    wss.on("connection", (ws) => {
        let accountId = "", jid = "", authed = false;
        const D = "prod.ol.epicgames.com";

        ws.on("message", (raw) => {
            const m = raw.toString();
            if (m.startsWith("<open")) {
                ws.send(`<open xmlns="urn:ietf:params:xml:ns:xmpp-framing" from="${D}" id="${uuid()}" version="1.0" xml:lang="en"/>`);
                ws.send(authed
                    ? `<stream:features xmlns:stream="http://etherx.jabber.org/streams"><bind xmlns="urn:ietf:params:xml:ns:xmpp-bind"/><session xmlns="urn:ietf:params:xml:ns:xmpp-session"/></stream:features>`
                    : `<stream:features xmlns:stream="http://etherx.jabber.org/streams"><mechanisms xmlns="urn:ietf:params:xml:ns:xmpp-sasl"><mechanism>PLAIN</mechanism></mechanisms></stream:features>`);
            } else if (m.startsWith("<auth")) {
                const b64 = m.replace(/<[^>]+>/g, "").trim();
                accountId = Buffer.from(b64, "base64").toString().split("\u0000")[1] || "";
                authed = true;
                ws.send(`<success xmlns="urn:ietf:params:xml:ns:xmpp-sasl"/>`);
            } else if (m.startsWith("<iq")) {
                const id = (/id="([^"]+)"/.exec(m) || [])[1] || "1";
                if (m.includes("xmpp-bind")) {
                    const resource = (/<resource>([^<]+)<\/resource>/.exec(m) || [])[1] || "fn";
                    jid = `${accountId}@${D}/${resource}`;
                    ws.send(`<iq to="${jid}" from="${D}" id="${id}" xmlns="jabber:client" type="result"><bind xmlns="urn:ietf:params:xml:ns:xmpp-bind"><jid>${jid}</jid></bind></iq>`);
                } else {
                    ws.send(`<iq to="${jid}" from="${D}" id="${id}" xmlns="jabber:client" type="result"/>`);
                }
            }
        });
        ws.on("error", () => { });
    });
};
﻿const crypto = require("crypto");

exports.err = (res, status, errorCode, errorMessage, numericErrorCode, extra = {}) =>
    res.status(status).json({
        errorCode, errorMessage, messageVars: [], numericErrorCode,
        originatingService: "any", intent: "prod", ...extra,
    });

exports.hex = (n = 16) => crypto.randomBytes(n).toString("hex");
exports.uuid = () => crypto.randomUUID();
exports.nextMidnight = () => {
    const d = new Date();
    d.setUTCHours(24, 0, 0, 0);
    return d.toISOString();
};
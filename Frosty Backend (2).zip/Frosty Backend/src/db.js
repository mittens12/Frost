﻿const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const config = require("../config.json");

const DIR = path.join(__dirname, "..", "data");
const FILE = path.join(DIR, "db.json");
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

let data = { accounts: {} };
if (fs.existsSync(FILE)) {
    try { data = JSON.parse(fs.readFileSync(FILE, "utf8")); }
    catch (e) { console.error("data/db.json is corrupt:", e.message); process.exit(1); }
}

let timer = null;
const flush = () => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
exports.save = () => { clearTimeout(timer); timer = setTimeout(flush, 250); };
process.on("SIGINT", () => { flush(); process.exit(0); });

const all = () => Object.values(data.accounts);
const lc = (s) => String(s || "").toLowerCase();

exports.all = all;
exports.byId = (id) => data.accounts[id];
exports.byEmail = (e) => all().find((a) => lc(a.email) === lc(e));
exports.byUsername = (u) => all().find((a) => lc(a.username) === lc(u));
exports.byDiscord = (d) => all().find((a) => a.discordId === d);

exports.create = ({ email, username, passwordHash, discordId }) => {
    const id = crypto.randomUUID().replace(/-/g, "");
    const defChar = config.defaultItems.find((i) => i.startsWith("AthenaCharacter:")) || "";
    const defPick = config.defaultItems.find((i) => i.startsWith("AthenaPickaxe:")) || "";
    const defGlider = config.defaultItems.find((i) => i.startsWith("AthenaGlider:")) || "";
    const defDance = config.defaultItems.find((i) => i.startsWith("AthenaDance:")) || "";
    const acc = {
        id, email: lc(email), username, passwordHash, discordId: discordId || null,
        banned: false, created: new Date().toISOString(), rvn: 1,
        vbucks: config.startingVbucks || 0,
        items: [...config.defaultItems],
        loadout: {
            character: defChar, pickaxe: defPick, glider: defGlider, backpack: "",
            skydivecontrail: "", musicpack: "", loadingscreen: "",
            dance: [defDance, "", "", "", "", ""],
            itemwraps: ["", "", "", "", "", "", ""],
        },
        battlepass: { purchased: false, level: 1, xp: 0, claimed: [] },
        stats: { wins: 0, kills: 0, matches: 0 },
    };
    data.accounts[id] = acc;
    exports.save();
    return acc;
};
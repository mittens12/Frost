﻿const fs = require("fs");
const path = require("path");
const db = require("./db");
const { nextMidnight } = require("./util");

const read = (f) => JSON.parse(fs.readFileSync(path.join(__dirname, "..", f), "utf8"));
const DAY = 864e5;

function rng(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6d2b79f5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function pick(list, count, seed) {
    const a = [...(list || [])], r = rng(seed);
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(r() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a.slice(0, Math.min(count || 0, a.length));
}

function shop() {
    const c = read("shop.json");
    const off = c.seedOffset || 0;
    const day = Math.floor(Date.now() / DAY);
    const span = c.featuredDays || 1;
    const period = Math.floor(day / span);
    return {
        daily: [...(c.fixedDaily || []), ...pick(c.dailyPool, c.dailyCount, day * 7919 + 1 + off)],
        featured: [...(c.fixedFeatured || []), ...pick(c.featuredPool, c.featuredCount, period * 104729 + 2 + off)],
        dailyEnd: new Date((day + 1) * DAY).toISOString(),
        featuredEnd: new Date((period + 1) * span * DAY).toISOString(),
    };
}
const bp = () => read("battlepass.json");

const owns = (acc, t) => acc.items.some((i) => i.toLowerCase() === t.toLowerCase());

function grantItems(acc, list) {
    const added = [];
    for (const t of list) if (!owns(acc, t)) { acc.items.push(t); added.push(t); }
    db.save();
    return added;
}

function addVbucks(acc, n) {
    acc.vbucks = Math.max(0, (acc.vbucks || 0) + n);
    db.save();
}

function claimRewards(acc) {
    const conf = bp(), b = acc.battlepass, granted = [];
    for (let tier = 1; tier <= b.level; tier++) {
        for (const [track, prefix] of [["free", "f"], ["paid", "p"]]) {
            if (track === "paid" && !b.purchased) continue;
            const key = prefix + tier;
            if (b.claimed.includes(key)) continue;
            for (const r of conf[track][tier] || []) {
                if (r.startsWith("vbucks:")) addVbucks(acc, parseInt(r.split(":")[1], 10) || 0);
                else granted.push(...grantItems(acc, [r]));
            }
            b.claimed.push(key);
        }
    }
    db.save();
    return granted;
}

function setLevel(acc, level) {
    const c = bp();
    acc.battlepass.level = Math.min(Math.max(1, level), c.maxLevel);
    acc.battlepass.xp = 0;
    return claimRewards(acc);
}

function givePass(acc) {
    acc.battlepass.purchased = true;
    return claimRewards(acc);
}

function addXp(acc, xp) {
    const c = bp(), b = acc.battlepass;
    b.xp += xp;
    while (b.xp >= c.xpPerLevel && b.level < c.maxLevel) { b.xp -= c.xpPerLevel; b.level++; }
    return claimRewards(acc);
}
// ---- daily V-Bucks
function claimDaily(acc) {
    const amount = require("../config.json").dailyVbucks || 100;
    const last = acc.lastDaily ? new Date(acc.lastDaily).getTime() : 0;
    const wait = last + DAY - Date.now();
    if (wait > 0) return { ok: false, waitMs: wait };
    acc.lastDaily = new Date().toISOString();
    addVbucks(acc, amount);
    acc.rvn++; db.save();
    return { ok: true, amount, total: acc.vbucks };
}

// ---- daily quests (progress comes from /gameserver/report)
const today = () => new Date().toISOString().slice(0, 10);

function quests(acc) {
    const q = read("quests.json");
    if (!acc.quests || acc.quests.date !== today()) {
        const seed = parseInt(today().replace(/-/g, ""), 10) + (acc.id.charCodeAt(0) || 0);
        acc.quests = {
            date: today(),
            list: pick(q.pool, q.dailyCount, seed).map((d) => ({ ...d, progress: 0, done: false })),
        };
        db.save();
    }
    return acc.quests;
}

// progress = { matches, kills, wins }; returns quests completed by this update
function questProgress(acc, progress) {
    const done = [];
    for (const qu of quests(acc).list) {
        if (qu.done) continue;
        qu.progress = Math.min(qu.target, qu.progress + (progress[qu.stat] || 0));
        if (qu.progress >= qu.target) { qu.done = true; addXp(acc, qu.xp); done.push(qu); }
    }
    db.save();
    return done;
}
const fail = (error, code = "errors.com.epicgames.modules.gamesubcatalog.purchase_not_allowed", num = 28004) =>
({ error, code, num });
const broke = () => fail("You do not have enough V-Bucks", "errors.com.epicgames.currency.mtx.insufficient", 1040);

function purchase(acc, offerId, qty) {
    const c = bp(), id = String(offerId).toLowerCase();

    if (id.includes("battlepass") && !id.includes("tier")) {
        if (acc.battlepass.purchased) return fail("You already own the Battle Pass");
        if (acc.vbucks < c.price) return broke();
        addVbucks(acc, -c.price);
        return { granted: givePass(acc) };
    }
    if (id.includes("tier")) {
        const cost = c.tierPrice * qty;
        if (acc.vbucks < cost) return broke();
        addVbucks(acc, -cost);
        return { granted: setLevel(acc, acc.battlepass.level + qty) };
    }

    const s = shop();
    const entry = [...s.daily, ...s.featured].find((e) => e.offerId === offerId);
    if (!entry) return fail("Offer not found", "errors.com.epicgames.modules.gamesubcatalog.catalog_out_of_date", 28000);
    if (entry.grants.every((g) => owns(acc, g))) return fail("You already own this item");
    if (acc.vbucks < entry.price) return broke();
    addVbucks(acc, -entry.price);
    return { granted: grantItems(acc, entry.grants) };
}

function catalog() {
    const s = shop(), exp = s.dailyEnd;
    const mk = (e, section, size) => {
        const name = e.grants[0].split(":")[1];
        return {
            offerId: e.offerId, devName: e.offerId, offerType: "StaticPrice",
            prices: [{ currencyType: "MtxCurrency", currencySubType: "", regularPrice: e.price, finalPrice: e.price, saleExpiration: "9999-12-31T23:59:59.999Z", basePrice: e.price }],
            categories: [], dailyLimit: -1, weeklyLimit: -1, monthlyLimit: -1, appStoreId: [],
            requirements: e.grants.map((g) => ({ requirementType: "DenyOnItemOwnership", requiredId: g, minQuantity: 1 })),
            metaInfo: [{ key: "SectionId", value: section }, { key: "TileSize", value: size }],
            catalogGroup: "", catalogGroupPriority: 0, sortPriority: 0,
            title: e.title || e.offerId, shortDescription: "", description: e.title || "",
            displayAssetPath: `/Game/Catalog/DisplayAssets/DA_${section}_${name}.DA_${section}_${name}`,
            itemGrants: e.grants.map((g) => ({ templateId: g, quantity: 1 })),
        };
    };
    return {
        refreshIntervalHrs: 1, dailyPurchaseHrs: 24, expiration: exp,
        storefronts: [
            { name: "BRDailyStorefront", catalogEntries: s.daily.map((e) => mk(e, "Daily", "Small")) },
            { name: "BRWeeklyStorefront", catalogEntries: s.featured.map((e) => mk(e, "Featured", "Normal")) },
        ],
    };
}

module.exports = { claimDaily, quests, questProgress, owns, grantItems, addVbucks, setLevel, givePass, addXp, claimRewards, purchase, catalog, shop, bp };
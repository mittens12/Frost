﻿const WebSocket = require("ws");
const crypto = require("crypto");
const config = require("../config.json");

const state = { build: "0", playlist: "playlist_defaultsolo" };
const sessions = new Map();
let current = null;

function assign() {
    const now = Date.now(), c = config.matchmaking;
    if (!current || current.count >= c.maxPlayersPerSession || now - current.created > c.joinWindowSec * 1000) {
        current = { id: crypto.randomBytes(16).toString("hex"), count: 0, created: now, ...state };
        sessions.set(current.id, current);
    }
    current.count++;
    return current;
}

function start() {
    const http = require("http");
    const httpServer = http.createServer((req, res) => {
        console.log(`[matchmaker] plain HTTP ${req.method} ${req.url} (not a websocket upgrade)`);
        res.writeHead(426, { "Content-Type": "text/plain" }); res.end("Upgrade Required");
    });
    httpServer.on("error", (e) => console.error(`[matchmaker] cannot listen on :${config.matchmakerPort} -> ${e.code || e.message}`));
    httpServer.on("upgrade", (req) => console.log(`[matchmaker] upgrade request ${req.url} protocols=${req.headers["sec-websocket-protocol"] || "-"} version=${req.headers["sec-websocket-version"] || "-"}`));
    const wss = new WebSocket.Server({ server: httpServer, perMessageDeflate: false, handleProtocols: (p) => [...p][0] });
    wss.on("error", (e) => console.error("[matchmaker] error:", e.message));
    wss.on("wsClientError", (e, socket, req) => console.error(`[matchmaker] handshake rejected: ${e.message}`));
    httpServer.listen(config.matchmakerPort, "0.0.0.0", () => console.log(`[matchmaker] ws listening on :${config.matchmakerPort}`));

    wss.on("connection", (ws) => {
        const ticketId = crypto.randomBytes(16).toString("hex");
        const send = (name, payload) => ws.readyState === WebSocket.OPEN && ws.send(JSON.stringify({ name, payload }));
        const wait = config.matchmaking.queueDelaySec * 1000;
        let session;

        const timers = [
            setTimeout(() => send("StatusUpdate", { state: "Connecting" }), 200),
            setTimeout(() => send("StatusUpdate", { totalPlayers: 1, connectedPlayers: 1, state: "Waiting" }), 1000),
            setTimeout(() => send("StatusUpdate", { ticketId, queuedPlayers: 0, estimatedWaitSec: 0, status: {}, state: "Queued" }), 2000),
            setTimeout(() => { session = assign(); send("StatusUpdate", { matchId: session.id, state: "SessionAssignment" }); }, 2000 + wait),
            setTimeout(() => send("Play", { matchId: session.id, sessionId: session.id, joinDelaySec: 1 }), 3500 + wait),
        ];
        ws.on("close", () => timers.forEach(clearTimeout));
        ws.on("error", () => { });
    });
    console.log(`[matchmaker] ws listening on :${config.matchmakerPort}`);
}

module.exports = { start, sessions, state };